title: C/C++字符串与数字相互转换函数总结
date: '2019-04-27 09:35:50'
updated: '2019-05-10 23:27:44'
tags: [C, C++]
permalink: /articles/2019/04/27/1556328950168.html
---
原文链接 [C/C++字符串与数字相互转换函数总结](https://www.tuhaoxin.cn/articles/2019/04/27/1556328950168.html)

最近在看编译器词法分析部分代码，里面遇到一些字符串转数字的函数，在此对C/C++字符串和整数相互转化函数做一个总结。包括atoi,atol,atoll,atof,strtol,strtoll,strtoul,strtoull,strtod,strtold,strtof,toascii,gcvt,tolower,toupper函数的用法。

### 字符串转整数

####  **atoi()**

* 功能

将字符串转换成整型数。

* 头文件 
``` 
#include<stdlib.h>  
```
* 定义函数  
```
int atoi(const char *nptr);  
```
* 函数说明  

      atoi()会扫描参数nptr字符串，跳过前面的空格字符，直到遇上数字或正负符号才开始做转换，而再遇到非数字或字符串结束时('')才结束转换，并将结果返回。
  
* 返回值  

      返回转换后的整型数。 
 
* 附加说明  

      atoi()与使用strtol(nptr，(char**)NULL，10)；结果相同。

#### **atol()**

* 功能

 将字符串转换成长整型数。

* 头文件  
```
#include<stdlib.h>  
```

* 定义函数  
```
long atol(const char *nptr);  
```

* 函数说明  

     atol()会扫描参数nptr字符串，跳过前面的空格字符，直到遇上数字或正负符号才开始做转换，而再遇到非数字或字符串结束时('')才结束转换，并将结果返回。  

* 返回值 
 
      返回转换后的长整型数。
  
* 附加说明  

      atol()与使用strtol(nptr,(char**)NULL,10)；结果相同。

####  **atof()**

* 功能

将字符串转换成浮点型数。

* 头文件  
```
#include <stdlib.h>  
```

* 定义函数  
```
double atof()(const char *nptr); 
```
 
* 函数说明  

      atof()会扫描参数nptr字符串，跳过前面的空格字符，直到遇上数字或正负符号才开始做转换，而再遇到非数字或字符串结束时('')才结束转换，并将结果返回。参数nptr字符串可包含正负号、小数点或E(e)来表示指数部分，如123.456或123e-2。 
 
* 返回值  

      返回转换后的浮点型数。
  
* 附加说明  

      atof()与使用strtod(nptr,(char**)NULL)结果相同。

#### **atoll()**

* 功能

将字符串转换成长长整型数。

* 头文件  
```
#include<stdlib.h>  
```

* 定义函数  

```
long long int atoll ( const char * str )
```

* 函数说明  

      和atol()一样，只是返回值为long long 型。

* 返回值 
 
      返回转换后的long long整型数。
  
#### **strtol()**

* 功能

将字符串转换成长整型数。

* 头文件  
```
#include<stdlib.h>  
```

* 定义函数
```  
long int strtol(const char *nptr,char **endptr,int base);
```
  
* 函数说明  

     strtol()会将参数nptr字符串根据参数base来转换成长整型数。参数base范围从2至36，或0。参数base代表采用的进制方式，如 base值为10则采用10进制，若base值为16则采用16进制等。当base值为0时则是采用10进制做转换，但遇到如'0x'前置字符则会使用 16进制做转换。一开始strtol()会扫描参数nptr字符串，跳过前面的空格字符，直到遇上数字或正负符号才开始做转换，再遇到非数字或字符串结束时('')结束转换，并将结果返回。若参数endptr不为NULL，则会将遇到不合条件而终止的nptr中的字符指针由endptr返回。
  
* 返回值 
 
      返回转换后的长整型数，否则返回ERANGE并将错误代码存入errno中。  

* 附加说明  

      ERANGE指定的转换字符串超出合法范围。

#### **strtoul()**

* 功能

将字符串转换成无符号长整型数。

* 头文件  
```
#include<stdlib.h>  
```

* 定义函数  
```
unsigned long int strtoul(const char *nptr,char **endptr, int base);  
```

* 函数说明 
 
      和strtol()类似。

* 返回值 
 
      返回转换后的长整型数，否则返回ERANGE并将错误代码存入errno中。  

* 附加说明  

      ERANGE指定的转换字符串超出合法范围。

#### **strtod()**

* 功能

将字符串转换成双精度浮点数。

* 头文件 
```
#include<stdlib.h>

```
* 定义函数  
```
double strtod(const char *nptr,char **endptr); 
```
 
* 函数说明 
 
      strtod()会扫描参数nptr字符串，跳过前面的空格字符，直到遇上数字或正负符号才开始做转换，到出现非数字或字符串结束时('')才结束转换，并将结果返回。若endptr不为NULL，则会将遇到不合条件而终止的nptr中的字符指针由endptr传回。参数nptr字符串可包含正负号、小数点或E(e)来表示指数部分。如123.456或123e-2。  

* 返回值  

      返回转换后的双精度浮点型数。

#### **strtold()**

* 功能

将字符串转换成长双精度浮点数。

* 头文件 
```
#include<stdlib.h>
```
* 定义函数  
```
long double strtold (const char* str, char** endptr);
```

* 函数说明 
 
      和strtod()类似。

* 返回值  

      返回转换后的长双精度浮点型数。


#### **strtof()**

* 功能

将字符串转换成单精度浮点数。

* 头文件 
```
#include<stdlib.h>
```
* 定义函数  
```
float strtof (const char* str, char** endptr);
```

* 函数说明 
 
      和strtod()类似。

* 返回值  

      返回转换后的单精度浮点型数。

####  **strtoll()**

* 功能

将字符串转换成长长整数。

* 头文件 
```
#include<stdlib.h>
```
* 定义函数  
```
long long int strtoll (const char* str, char** endptr, int base);
```
* 函数说明 
 
      参考strtol()。

* 返回值  

      返回转换后的长长整型数。

####  **strtoull()**

* 功能

将字符串转换成无符号长长整数。

* 头文件 
```
#include<stdlib.h>
```
* 定义函数
```
unsigned long long int strtoull (const char* str, char** endptr, int base);
```

* 函数说明 
 
      参考strtoul()。

* 返回值  

      返回转换后的无符号长长整型数。

### 整数转字符

####  **toascii()**

* 功能

 将整型数转换成合法的ASCII 码字符。

* 头文件  
```
#include<ctype.h>  
```
* 定义函数 
``` 
int toascii(int c) 
``` 

* 函数说明 
 
     toascii()会将参数c转换成7位的unsigned char值，第八位则会被清除，此字符即会被转成ASCII码字符。
  
* 返回值  
      将转换成功的ASCII码字符值返回。

#### **gcvt()**

* 功能

将浮点型数转换为字符串，取四舍五入

* 头文件  
```
#include<stdlib.h>
```
  
* 定义函数 
``` 
char *gcvt(double number，size_t ndigits，char *buf);  
```

* 函数说明  

      gcvt()用来将参数number转换成ASCII码字符串，参数ndigits表示显示的位数。gcvt()与ecvt()和fcvt()不同的地方在于，gcvt()所转换后的字符串包含小数点或正负符号。若转换成功，转换后的字符串会放在参数buf指针所指的空间。  

* 返回值  

      返回一字符串指针，此地址即为buf指针。  

### 其他

#### **tolower()**

* 功能

将大写字母转换成小写字母

* 头文件  
```
#include<stdlib.h> 
``` 
* 定义函数 
``` 
int tolower(int c);  
```
* 函数说明  

      若参数c为大写字母则将该对应的小写字母返回。  

* 返回值  

      返回转换后的小写字母，若不须转换则将参数c值返回。

####  **toupper()**

* 功能

将小写字母转换成大写字母

* 头文件  
```
#include<ctype.h>  
```

* 定义函数 
``` 
int toupper(int c); 
```
 
* 函数说明  

     若参数c为小写字母则将该对映的大写字母返回。
  
* 返回值  

     返回转换后的大写字母，若不须转换则将参数c值返回。

### 示例代码

```
#include <libc.h>
#include <stdlib.h>
#include <iostream>
#include <ctype.h>

using namespace std;

int main()
{
    // atoi()
    char str1[] = "123";
    int num1 = atol(str1);
    cout << "atoi() return is " << num1 << endl;

    // atol
    char str2[] = "10000002";
    long int num2 = atol(str2);
    cout << "atol() return is " << num2 << endl;

    // atoll()
    char big_num1[] = "8239206483232728";
    long long int num3 = atoll(big_num1);
    cout << "atoll() return  is " << num3 << endl;

    // atof()
    char pi[] = "3.1415926535";
    double pi_val = atof(pi);
    cout <<  "atof() return is " << pi_val << "\n";

    // strtod()
    char a[] = "365.24 29.53";
    char* paEnd;
    double a1, a2;
    a1 = strtod (a, &paEnd);
    a2 = strtod (paEnd, NULL);
    cout << "strtold() return 1 is "<< a1 << endl;
    cout << "strtold() return 2 is " << a2 << endl;


    // strtold()
    char b[] = "365.24676767 29.5378867687";
    char* pbEnd;
    long double b1, b2;
    b1 = strtold (b, &pbEnd);
    b2 = strtold (pbEnd, NULL);
    cout << "strtod() return 1 is "<< b1 << endl;
    cout << "strtod() return 2 is " << b2 << endl;

    // strtof()
    char c[] = "365.24676767 29.5378867687";
    char* pcEnd;
    float c1, c2;
    c1 = strtof(c, &pcEnd);
    c2 = strtof(pcEnd, NULL);
    cout << "strtof() return 1 is " << c1 << endl;
    cout << "strtof() return 2 is " << c2 << endl;

    //strtol(), stroll()类似
    char d1[]= "1000000000";
    char d2[]= "100000000";
    char d3[]= "ffff";
    long int dd1,dd2,dd3;
    dd1 = strtol(d1,NULL,10);
    dd2 = strtol(d2,NULL,2);
    dd3 = strtol(d3,NULL,16);
    cout << "strtol() return 1 is " << dd1 << endl;
    cout << "strtol() return 2 is " <<  dd2 << endl;
    cout << "strtol() return 3 is " << dd3 << endl;

    //strtoul(), strtoull()类似
    char e1[]= "1000000000";
    char e2[]= "100000000000000000";
    char e3[]= "ffff";
    long int ee1,ee2,ee3;
    ee1 = strtoul(e1,NULL,10);
    ee2 = strtoul(e2,NULL,2);
    ee3 = strtoul(e3,NULL,16);
    cout << "strtoul() return 1 is " << ee1 << endl;
    cout << "strtoul() return 2 is " <<  ee2 << endl;
    cout << "strtoul() return 3 is " << ee3 << endl;

    //toascii()
    int aa=217;
    char bb;
    printf("before toascii () : a value =%d(%c)\n",aa,aa);
    bb = toascii(aa);
    printf( "after toascii() : a value =%d(%c)\n ",bb,bb);

    //gcvt()
    char buffer [20];
    gcvt (1365.249,6,buffer);
    cout << "gcvt() return is " << buffer << endl;
    gcvt (1365.249,3,buffer);
    cout << "gcvt() return is " << buffer << endl;

    //tolower(), toupper()
    char s[]= "aBcDeFgH12345;!#$";
    int i;
    printf("before tolower() : %s\n",s);
    for(i=0;i<sizeof(s);i++)
        s[i] = tolower(s[i]);
    printf("after tolower() : %s\n" ,s);
    for(i=0;i<sizeof(s);i++)
        s[i] = toupper(s[i]);
    printf("after toupper() : %s\n" ,s);

    return 0;
} 
```

输出
```
atoi() return is 123
atol() return is 10000002
atoll() return  is 8239206483232728
atof() return is 3.14159
strtold() return 1 is 365.24
strtold() return 2 is 29.53
strtod() return 1 is 365.247
strtod() return 2 is 29.5379
strtof() return 1 is 365.247
strtof() return 2 is 29.5379
strtol() return 1 is 1000000000
strtol() return 2 is 256
strtol() return 3 is 65535
strtoul() return 1 is 1000000000
strtoul() return 2 is 131072
strtoul() return 3 is 65535
before toascii () : a value =217(�)
after toascii() : a value =89(Y)
gcvt() return is 1365.25
gcvt() return is 1.37e+03
before tolower() : aBcDeFgH12345;!#$
after tolower() : abcdefgh12345;!#$
after toupper() : ABCDEFGH12345;!#$
```