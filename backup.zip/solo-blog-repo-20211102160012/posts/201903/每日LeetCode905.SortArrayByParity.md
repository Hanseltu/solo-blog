title: '[每日LeetCode] 905. Sort Array By Parity'
date: '2019-03-03 21:37:19'
updated: '2019-03-09 22:11:26'
tags: [LeetCode, Array, Easy]
permalink: /articles/2019/03/03/1551619834877.html
---
**Description:**

Given an array `A` of non-negative integers, return an array consisting of all the even elements of `A` , followed by all the odd elements of `A` .

You may return any answer array that satisfies this condition.

**Example 1:**

```
Input: [3,1,2,4]
Output: [2,4,3,1]
The outputs [4,2,3,1], [2,4,1,3], and [4,2,1,3] would also be accepted.
```

**Note:**

1.  `1 <= A.length <= 5000`
2.  `0 <= A[i] <= 5000`

-----
思路：题目要求数组中所有的奇数要在偶数后面，考虑使用两个变量分别从数组头开始，一个向前移动（当前数为偶数），一个用来交换（当前数为奇数）。

-----
我的C++代码

```
class Solution {
public:
    vector<int> sortArrayByParity(vector<int>& A) {
         for (int i = 0, j = 0; j < A.size(); j++){
            if (A[j] % 2 == 0) 
              swap(A[i++], A[j]);
         }
        return A;
    }
};
```

----
运行时间：32ms
运行内存：11.4M