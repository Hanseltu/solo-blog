title: '[每日LeetCode] 217. Contains Duplicate'
date: '2019-03-12 22:06:49'
updated: '2019-03-12 22:31:28'
tags: [LeetCode, Array, Easy]
permalink: /articles/2019/03/12/1552399609211.html
---
Description:

Given an array of integers, find if the array contains any duplicates.

Your function should return true if any value appears at least twice in the array, and it should return false if every element is distinct.

**Example 1:**

```
Input: [1,2,3,1]
Output: true
```

**Example 2:**

```
Input: [1,2,3,4]
Output: false
```

**Example 3:**

```
Input: [1,1,1,3,3,4,3,2,4,2]
Output: true
```

-----
思路：题目要求判断数组中有无重复元素。考虑首先对数组进行排序，然后将比较相邻的两个数是否有相等的，如有返回true，否则返回false。

-----
C++代码
```
class Solution {
public:
    bool containsDuplicate(vector<int>& nums) {
        sort(nums.begin(), nums.end());
        for(int i = 1; i < nums.size(); i ++){
            if(nums[i] == nums[i - 1])
                return true;
        }
        return false;
    }
};
```
----
运行时间：32ms
运行内存：11.4M