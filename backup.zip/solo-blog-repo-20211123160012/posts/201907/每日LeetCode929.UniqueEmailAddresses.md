title: '[每日LeetCode] 929. Unique Email Addresses'
date: '2019-07-03 22:25:10'
updated: '2021-03-27 16:14:56'
tags: [LeetCode, String, Easy]
permalink: /articles/2019/07/03/1562163910614.html
---
原文链接 [[每日LeetCode] 929. Unique Email Addresses](http://www.tuhaoxin.cn/articles/2019/07/03/1562163910614.html)

**Description:**

Every email consists of a local name and a domain name, separated by the @ sign.

For example, in `alice@leetcode.com` ,  `alice` is the local name, and `leetcode.com`is the domain name.

Besides lowercase letters, these emails may contain `'.'` s or `'+'` s.

If you add periods ( `'.'` ) between some characters in the **local name** part of an email address, mail sent there will be forwarded to the same address without dots in the local name.  For example, `"alice.z@leetcode.com"` and `"alicez@leetcode.com" `forward to the same email address.  (Note that this rule does not apply for domain names.)

If you add a plus ( `'+'` ) in the **local name** , everything after the first plus sign will be **ignored** . This allows certain emails to be filtered, for example `m.y+name@email.com` will be forwarded to `my@email.com`.  (Again, this rule does not apply for domain names.)

It is possible to use both of these rules at the same time.

Given a list of `emails`, we send one email to each address in the list.  How many different addresses actually receive mails? 

**Example 1:**

```
Input: ["test.email+alex@leetcode.com","test.e.mail+bob.cathy@leetcode.com","testemail+david@lee.tcode.com"]
Output: 2
Explanation: "testemail@leetcode.com" and "testemail@lee.tcode.com" actually receive mails
```

**Note:**

* `1 <= emails[i].length <= 100`
* `1 <= emails.length <= 100`
* Each`emails[i]`contains exactly one`'@'`character.
* All local and domain names are non-empty.
* Local names do not start with a`'+'`character.

---

思路：本题要求判断字符串数组中邮箱地址的唯一性。需要注意的是 `.` 和 `+` 的特殊意义，可以遍历emails中的每个邮箱地址，然后依次进行如下操作：

* 分别保存数组元素中的用户名和域名；
* 从前往后遍历用户名的每个字符，如果遇到'+'，则直接截断；如果遇到'.'，则忽略该字符；
* 将新用户名和域名重新组合，再插入哈希表中
  最终哈希表的大小就是答案。

---

C++代码

```
class Solution {
public:
    int numUniqueEmails(vector<string>& emails) {
        unordered_set<string> S;
        for (auto email : emails)
        {
            string local, domain;
            int k = 0;
            while (email[k] != '@') k ++ ;
            local = email.substr(0, k);
            domain = email.substr(k + 1);
            string newLocal;
            for (auto c : local)
            {
                if (c == '+') break;
                if (c != '.') newLocal += c;
            }
            S.insert(newLocal + '@' + domain);
        }
        return S.size();
    }
};
```

---

运行时间：32ms

运行内存：14.4M
