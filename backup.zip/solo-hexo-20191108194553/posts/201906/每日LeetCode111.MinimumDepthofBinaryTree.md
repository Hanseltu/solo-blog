title: '[每日LeetCode] 111. Minimum Depth of Binary Tree'
date: '2019-06-06 12:15:26'
updated: '2019-06-06 12:16:17'
tags: [LeetCode, Tree, Easy]
permalink: /articles/2019/06/06/1559794526600.html
---
原文链接 [[每日LeetCode] 111. Minimum Depth of Binary Tree](https://www.tuhaoxin.cn/articles/2019/06/06/1559794526600.html)


**Description:**

Given a binary tree, find its minimum depth.

The minimum depth is the number of nodes along the shortest path from the root node down to the nearest leaf node.

**Note:** A leaf is a node with no children.

**Example:**

Given binary tree`[3,9,20,null,null,15,7]`,

```
    3
   / \
  9  20
    /  \
   15   7
```

return its minimum depth = 2.

----

思路：本题要求二叉树的最小深度，注意和 [[每日LeetCode] 104. Maximum Depth of Binary Tree](https://www.tuhaoxin.cn/articles/2019/05/20/1558361941066.html) 的区别。本题依旧使用递归思想，需要注意的是在计算左子树和右子树深度的时候，判断是否等于0，如果等于0，说明该子树不存在，深度赋值为最大值。

----
C++代码

```
/**
 * Definition for a binary tree node.
 * struct TreeNode {
 *     int val;
 *     TreeNode *left;
 *     TreeNode *right;
 *     TreeNode(int x) : val(x), left(NULL), right(NULL) {}
 * };
 */
class Solution {
public:
    int minDepth(TreeNode* root) {
         if(!root)
            return 0;
        if(!root->left && !root->right)
            return 1;
        int leftDepth = minDepth(root->left);
        int rightDepth = minDepth(root->right);
        if(leftDepth == 0)
            leftDepth = INT_MAX; 
        if(rightDepth == 0)
            rightDepth = INT_MAX;
        return leftDepth < rightDepth ? (leftDepth + 1) : (rightDepth + 1);
    }
};
```

---
运行时间：8ms

运行内存：19.6M