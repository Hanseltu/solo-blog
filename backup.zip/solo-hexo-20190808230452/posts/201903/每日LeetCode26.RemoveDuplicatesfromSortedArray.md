title: '[每日LeetCode] 26. Remove Duplicates from Sorted Array'
date: '2019-03-15 22:39:29'
updated: '2019-03-15 22:50:45'
tags: [LeetCode, Array, Easy]
permalink: /articles/2019/03/15/1552660768959.html
---
Description：

Given a sorted array _nums_ , remove the duplicates [**in-place** ](https://en.wikipedia.org/wiki/In-place_algorithm) such that each element appear only_once_and return the new length.

Do not allocate extra space for another array, you must do this by **modifying the input array [in-place] (https://en.wikipedia.org/wiki/In-place_algorithm)** with O(1) extra memory.

**Example 1:**

```
Given nums = [1,1,2],

Your function should return length =  2, with the first two elements of nums being 1 and 2 respectively.

It doesn't matter what you leave beyond the returned length.
```

**Example 2:**

```
Given nums = [0,0,1,1,1,2,2,3,3,4],

Your function should return length = 5, with the first five elements of nums being modified to 0, 1, 2, 3 and 4 respectively.

It doesn't matter what values are set beyond the returned length.
```

----
思路：本题要求去除已排序数组中重复的元素，并返回数组大小。考虑从前往后找，找到一个和前一个数字不同的就放到前面，相同的话不予处理。

---
C++代码
```
class Solution {
public:
     int removeDuplicates(vector<int>& nums) {
        if(nums.size()==0) return 0;
        int len = 1;
        for(int i=1;i<nums.size();i++){
            
            if(nums[i]!=nums[i-1]){
                nums[len++] = nums[i];
            }
        }
        return len;
    }
};
```

----
运行时间：32ms
运行内存：10.7M
