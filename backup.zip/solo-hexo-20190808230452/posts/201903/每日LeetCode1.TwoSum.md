title: '[每日LeetCode] 1. Two Sum'
date: '2019-03-20 22:02:18'
updated: '2019-03-20 22:06:35'
tags: [LeetCode, Array, Easy]
permalink: /articles/2019/03/20/1553090537977.html
---
Description:

Given an array of integers, return **indices** of the two numbers such that they add up to a specific target.

You may assume that each input would have **_exactly_** one solution, and you may not use the _same_ element twice.

**Example:**

```
Given nums = [2, 7, 11, 15], target = 9,

Because nums[0] + nums[1] = 2 + 7 = 9,
return [0, 1].
```

----
思路：本题要求寻找和为target的两个元素下标。考虑使用map结构，将数组保存至unordered_map中，存入一个元素则判断一次，直到所有的元素判断完。

---
C++代码

```
class Solution {
public:
    vector<int> twoSum(vector<int>& nums, int target) {
        unordered_map<int,int> dic;
        vector<int> result;
        for(int i = 0; i < nums.size(); ++i) {
            int numberToFind = target - nums[i];
            if (dic.find(numberToFind) != dic.end()) {
                result.push_back(dic[numberToFind]);
                result.push_back(i);
                return result;     
            }
            dic[nums[i]] = i;
        }
        return result;
    }
};
```
---
运行时间： 12ms

运行内存：9.5M

