title: '[每日LeetCode] 707. Design Linked List'
date: '2019-04-28 21:23:08'
updated: '2019-04-28 21:29:54'
tags: [LeetCode, LinkList, Easy]
permalink: /articles/2019/04/28/1556457788530.html
---
Description:

Design your implementation of the linked list. You can choose to use the singly linked list or the doubly linked list. A node in a singly linked list should have two attributes: `val` and `next`. `val`is the value of the current node, and `next` is a pointer/reference to the next node. If you want to use the doubly linked list, you will need one more attribute `prev` to indicate the previous node in the linked list. Assume all nodes in the linked list are 0-indexed.

Implement these functions in your linked list class:

*   get(index) : Get the value of the `index` -th node in the linked list. If the index is invalid, return `-1`.
*   addAtHead(val) : Add a node of value `val` before the first element of the linked list. After the insertion, the new node will be the first node of the linked list.
*   addAtTail(val) : Append a node of value `val` to the last element of the linked list.
*   addAtIndex(index, val) : Add a node of value `val` before the `index`-th node in the linked list. If `index` equals to the length of linked list, the node will be appended to the end of linked list. If index is greater than the length, the node will not be inserted.
*   deleteAtIndex(index) : Delete the`index`-th node in the linked list, if the index is valid.

**Example:**

```
MyLinkedList linkedList = new MyLinkedList();
linkedList.addAtHead(1);
linkedList.addAtTail(3);
linkedList.addAtIndex(1, 2);  // linked list becomes 1->2->3
linkedList.get(1);            // returns 2
linkedList.deleteAtIndex(1);  // now the linked list is 1->3
linkedList.get(1);            // returns 3
```

**Note:**

*   All values will be in the range of `[1, 1000]`.
*   The number of operations will be in the range of `[1, 1000]`.
*   Please do not use the built-in LinkedList library.

---
思路：本题要求自己设计实现链表的基本操作，不能使用已有的模板函数，用双链表或者单链表均可。单链表处理起来稍微简单点，这里使用单链表进行操作，主要注意各个操作处理的细节，开始提交时忘记判断index小于0的情况，导致没有通过，加上这个判断就好了。

---
C++代码

```
class Node{
public:
    int val;
    Node* next;
    Node(int val){this->val = val; next = NULL;}
};
class MyLinkedList {
public:
    /** Initialize your data structure here. */
    int size = 0;
    Node* head = new Node(0);
    MyLinkedList() {
        
    }
    /** Get the value of the index-th node in the linked list. If the index is invalid, return -1. */
    int get(int index) {
        if (index >= size || index < 0)
            return -1;
        Node* temp = head->next;
        for(int i=0; i<index; i++)
            temp = temp->next;
        return temp->val;
    } 
    /** Add a node of value val before the first element of the linked list. After the insertion, the new node will be the first node of the linked list. */
    void addAtHead(int val) {
        Node* temp = head->next;
        head->next = new Node(val);
        head->next->next = temp;
        size++;
    }    
    /** Append a node of value val to the last element of the linked list. */
    void addAtTail(int val) {
        Node* temp = head;
        while(temp->next != NULL)
            temp = temp->next;
        temp->next = new Node(val);
        size++;
    } 
    /** Add a node of value val before the index-th node in the linked list. If index equals to the length of linked list, the node will be appended to the end of linked list. If index is greater than the length, the node will not be inserted. */
    void addAtIndex(int index, int val) {
        if (index > size )
            return;
        Node* temp = head;
        for(int i=0; i<index; i++)
            temp = temp->next;
        Node* temp1 = temp->next;
        temp->next = new Node(val);
        temp->next->next = temp1;
        size++;
    }    
    /** Delete the index-th node in the linked list, if the index is valid. */
    void deleteAtIndex(int index) {
        if (index >= size || index < 0)
            return;
        Node* temp = head;
        for(int i=0; i<index; i++)
            temp = temp->next;
        Node* temp1 = temp->next;
        temp->next = temp1->next;
        temp1->next = NULL;
        size--;
        delete temp1;
    }
};
/**
 * Your MyLinkedList object will be instantiated and called as such:
 * MyLinkedList* obj = new MyLinkedList();
 * int param_1 = obj->get(index);
 * obj->addAtHead(val);
 * obj->addAtTail(val);
 * obj->addAtIndex(index,val);
 * obj->deleteAtIndex(index);
 */
```

---
运行时间：52ms

运行内存：19.3M