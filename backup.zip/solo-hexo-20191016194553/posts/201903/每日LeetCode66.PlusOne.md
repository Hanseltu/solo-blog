title: '[每日LeetCode] 66. Plus One'
date: '2019-03-18 23:15:52'
updated: '2019-03-19 08:36:35'
tags: [LeetCode, Array, Easy]
permalink: /articles/2019/03/18/1552922152665.html
---
Description:

Given a **non-empty** array of digits representing a non-negative integer, plus one to the integer.

The digits are stored such that the most significant digit is at the head of the list, and each element in the array contain a single digit.

You may assume the integer does not contain any leading zero, except the number 0 itself.

**Example 1:**

```
Input: [1,2,3]
Output: [1,2,4]
Explanation: The array represents the integer 123.
```

**Example 2:**

```
Input: [4,3,2,1]
Output: [4,3,2,2]
Explanation: The array represents the integer 4321.
```

----
思路：本题要求在有序数组的最后加1，加1后的效果如正常的数字相加需要考虑进位。主要考虑最后一个数字是否为9，若不为9则直接+1，若为9，需要考虑—+1后进位和不进位两种情况。

----
C++代码

```
class Solution {
public:
    vector<int> plusOne(vector<int>& digits) {
        for(int i = digits.size() - 1; i >= 0; i--)   
        {
            if(digits[i] != 9)
            {
                digits[i] ++;
                break;
            }
            digits[i] = 0;
        }
        if(digits[0] == 0)
            digits.insert(digits.begin(), 1);
        return digits;
    }
};
```

----
运行时间：12ms

运行内存：8.4M


