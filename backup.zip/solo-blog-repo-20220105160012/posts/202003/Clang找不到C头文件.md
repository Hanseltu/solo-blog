title: Clang++ 找不到 C++ 头文件
date: '2020-03-09 12:08:58'
updated: '2020-03-09 12:11:12'
tags: [Clang, 问题解决, 记录]
permalink: /articles/2020/03/09/1583726938039.html
---
原文链接：[Clang++ 找不到 C++ 头文件](https://www.tuhaoxin.cn/articles/2020/03/09/1583726938039.html)

**问题**：当在 Ubuntu18.04 上第一次使用 clang++ 编译 C/C++ 项目时，可能会遇到找不到头文件的情况，如

```C
clang++ -O3 -fPIC -std=c++11 -c -o gen/out.pb.o gen/out.pb.cc
In file included from gen/out.pb.cc:4:
./gen/out.pb.h:7:10: fatal error: 'limits' file not found
#include <limits>
         ^~~~~~~~
1 error generated.
Makefile:26: recipe for target 'gen/out.pb.o' failed
```

**原因**：clang++ 会自动选择目前环境下的 gcc 头文件，如果找不到就会报错，执行 `clang++ -v` 看环境下提供的头文件有哪些

```
haoxin@instance:~/gcp-ubuntu/github/k-vim$ clang++ -v
clang version 6.0.1-svn334776-1~exp1~20190309042703.125 (branches/release_60)
Target: x86_64-pc-linux-gnu
Thread model: posix
InstalledDir: /usr/bin
Found candidate GCC installation: /usr/bin/../lib/gcc/x86_64-linux-gnu/7
Found candidate GCC installation: /usr/bin/../lib/gcc/x86_64-linux-gnu/7.5.0
Found candidate GCC installation: /usr/bin/../lib/gcc/x86_64-linux-gnu/8
Found candidate GCC installation: /usr/lib/gcc/x86_64-linux-gnu/7
Found candidate GCC installation: /usr/lib/gcc/x86_64-linux-gnu/7.5.0
Found candidate GCC installation: /usr/lib/gcc/x86_64-linux-gnu/8
Selected GCC installation: /usr/bin/../lib/gcc/x86_64-linux-gnu/8
Candidate multilib: .;@m64
Selected multilib: .;@m64
```

可以看到 `Selected GCC installation: /usr/bin/../lib/gcc/x86_64-linux-gnu/8` 这一行，clang++ 会 自动找到 gcc-8 的头文件，而 Ubuntu18.04 默认的 gcc 版本是 7.3，因此会找不到头文件。

**解决方案**

执行 `sudo apt install g++-8` 安装 gcc-8 的头文件，即可成功。

注：可能安装的不是 gcc++-8 ，一般安装 `Selected GCC installation` 的版本。
