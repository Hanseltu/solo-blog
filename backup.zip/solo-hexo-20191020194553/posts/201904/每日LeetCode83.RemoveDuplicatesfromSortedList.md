title: '[每日LeetCode] 83. Remove Duplicates from Sorted List'
date: '2019-04-24 12:27:07'
updated: '2019-04-25 12:47:04'
tags: [LeetCode, LinkList, Easy]
permalink: /articles/2019/04/24/1556080027006.html
---
Description:

Given a sorted linked list, delete all duplicates such that each element appear only _once_.

**Example 1:**

```
Input: 1->1->2
Output: 1->2
```

**Example 2:**

```
Input: 1->1->2->3->3
Output: 1->2->3
```

---
思路：本题要求删除链表中重复的元素。比较简单，依次遍历链表节点并比较，若连续两个节点元素相等则直接修改指针即可。

---
C++代码

```
/**
 * Definition for singly-linked list.
 * struct ListNode {
 *     int val;
 *     ListNode *next;
 *     ListNode(int x) : val(x), next(NULL) {}
 * };
 */
class Solution {
public:
    ListNode* deleteDuplicates(ListNode* head) {
        ListNode* curr = head;
        while(curr && curr->next){
            if (curr->val == curr->next->val){
                ListNode *temp = curr->next;
                curr->next = temp->next;
                delete temp;
            }
            else
                curr = curr->next;
        }
        return head;
    }
};
```

----
运行时间：12ms

运行内存：9.1M