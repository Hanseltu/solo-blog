title: '[每日LeetCode] 160. Intersection of Two Linked Lists'
date: '2019-04-29 22:20:45'
updated: '2019-04-29 22:41:10'
tags: [LeetCode, LinkList, Easy]
permalink: /articles/2019/04/29/1556547645353.html
---
Description:

Write a program to find the node at which the intersection of two singly linked lists begins.

For example, the following two linked lists:

[![](https://assets.leetcode.com/uploads/2018/12/13/160_statement.png)](https://assets.leetcode.com/uploads/2018/12/13/160_statement.png)

begin to intersect at node c1.

**Example 1:**

[![](https://assets.leetcode.com/uploads/2018/12/13/160_example_1.png)](https://assets.leetcode.com/uploads/2018/12/13/160_example_1.png)

```
Input: intersectVal = 8, listA = [4,1,8,4,5], listB = [5,0,1,8,4,5], skipA = 2, skipB = 3
Output: Reference of the node with value = 8
Input Explanation: The intersected node's value is 8 (note that this must not be 0 if the two lists intersect). From the head of A, it reads as [4,1,8,4,5]. From the head of B, it reads as [5,0,1,8,4,5]. There are 2 nodes before the intersected node in A; There are 3 nodes before the intersected node in B.
```

**Example 2:**

[![](https://assets.leetcode.com/uploads/2018/12/13/160_example_2.png)](https://assets.leetcode.com/uploads/2018/12/13/160_example_2.png)

```
Input: intersectVal = 2, listA = [0,9,1,2,4], listB = [3,2,4], skipA = 3, skipB = 1
Output: Reference of the node with value = 2
Input Explanation: The intersected node's value is 2 (note that this must not be 0 if the two lists intersect). From the head of A, it reads as [0,9,1,2,4]. From the head of B, it reads as [3,2,4]. There are 3 nodes before the intersected node in A; There are 1 node before the intersected node in B.
```

**Example 3:**

[![](https://assets.leetcode.com/uploads/2018/12/13/160_example_3.png)](https://assets.leetcode.com/uploads/2018/12/13/160_example_3.png)

```
Input: intersectVal = 0, listA = [2,6,4], listB = [1,5], skipA = 3, skipB = 2
Output: null
Input Explanation: From the head of A, it reads as [2,6,4]. From the head of B, it reads as [1,5]. Since the two lists do not intersect, intersectVal must be 0, while skipA and skipB can be arbitrary values.
Explanation: The two lists do not intersect, so return null.
```

**Notes:**

*   If the two linked lists have no intersection at all, return `null`.
*   The linked lists must retain their original structure after the function returns.
*   You may assume there are no cycles anywhere in the entire linked structure.
*   Your code should preferably run in O(n) time and use only O(1) memory.

---
思路一：本题要求寻找两个链表的交点。分别遍历两个链表，得到分别对应的长度，然后求长度的差值，把较长的那个链表向后移动这个差值的个数，然后一一比较即可。

思路二：还有一种比较新奇的做法，刚开始看到有点懵了，理解了之后感觉真的高大上！！！具体做法为：让两条链表分别从各自的开头开始往后遍历，当其中一条遍历到末尾时，跳到另一个条链表的开头继续遍历，保证两个指针走过的路程是相等的，此时再判断两个链表是否相等。


---
C++代码（思路一）
```
/**
 * Definition for singly-linked list.
 * struct ListNode {
 *     int val;
 *     ListNode *next;
 *     ListNode(int x) : val(x), next(NULL) {}
 * };
 */
class Solution {
public:
    ListNode *getIntersectionNode(ListNode *headA, ListNode *headB) {
        if (!headA || !headB) 
		return NULL;
        int lenA = getLength(headA), lenB = getLength(headB);
        if (lenA < lenB) {
            for (int i = 0; i < lenB - lenA; ++i) 
		headB = headB->next;
        } else {
            for (int i = 0; i < lenA - lenB; ++i) 
		headA = headA->next;
        }
        while (headA && headB && headA != headB) {
            headA = headA->next;
            headB = headB->next;
        }
        return (headA && headB) ? headA : NULL;
    }
    int getLength(ListNode* head) {
        int cnt = 0;
        while (head) {
            ++cnt;
            head = head->next;
        }
        return cnt;
    }
};
```

运行时间：52ms

运行内存：16.9M

---
C++代码（思路二）

```
/**
 * Definition for singly-linked list.
 * struct ListNode {
 *     int val;
 *     ListNode *next;
 *     ListNode(int x) : val(x), next(NULL) {}
 * };
 */
class Solution {
public:
    ListNode *getIntersectionNode(ListNode *headA, ListNode *headB) {
         if (!headA || !headB) return NULL;
        ListNode *listA = headA, *listB = headB;
        while (listA && listB) {
            if (listA == listB) 
                return listA;
            listA = listA->next;
            listB = listB->next;

            if (listA == listB) 
                return listA;
            if (listA == NULL) listA = headB;
            if (listB == NULL) listB = headA;
        }
        return listA;
    }
};
```

运行时间：52ms

运行内存：16.8M
