title: '[每日LeetCode] 989. Add to Array-Form of Integer'
date: '2019-04-16 22:04:07'
updated: '2019-04-16 22:12:07'
tags: [LeetCode, Array, Easy]
permalink: /articles/2019/04/16/1555423447817.html
---
Description:

For a non-negative integer `X`, the  _array-form of  `X`_ is an array of its digits in left to right order.  For example, if `X = 1231`, then the array form is `[1,2,3,1]`.

Given the array-form `A` of a non-negative integer `X`, return the array-form of the integer `X+K`.

**Example 1:**

```
Input: A = [1,2,0,0], K = 34
Output: [1,2,3,4]
Explanation: 1200 + 34 = 1234
```

**Example 2:**

```
Input: A = [2,7,4], K = 181
Output: [4,5,5]
Explanation: 274 + 181 = 455
```

**Example 3:**

```
Input: A = [2,1,5], K = 806
Output: [1,0,2,1]
Explanation: 215 + 806 = 1021
```

**Example 4:**

```
Input: A = [9,9,9,9,9,9,9,9,9,9], K = 1
Output: [1,0,0,0,0,0,0,0,0,0,0]
Explanation: 9999999999 + 1 = 10000000000
```

**Note：**
1.  `1 <= A.length <= 10000`
2.  `0 <= A[i] <= 9`
3.  `0 <= K <= 10000`
4.  If `A.length > 1`, then `A[0] != 0`

---
思路：本题的意思要把数组中的元素当做整数，并将此整数加上K后的整数转化为新的数组。考虑首先把数组逆序，然后提取整数K的各位上的数分别和数组中的元素相加，注意判断是否有进位，操作完成后再逆序输出。

---
C++代码
```
class Solution {
public:
    vector<int> addToArrayForm(vector<int>& A, int K) {
    reverse(A.begin(), A.end());
    for (int i = 0; i < A.size(); i++) {
        A[i] += K;
        K = A[i] / 10;
        A[i] %= 10;
    }
    while (K) {
        A.push_back(K%10);
        K /= 10;
    }
    reverse(A.begin(), A.end());
    return A;
    }
};
```
---
运行时间：116ms

运行内存：12.4M