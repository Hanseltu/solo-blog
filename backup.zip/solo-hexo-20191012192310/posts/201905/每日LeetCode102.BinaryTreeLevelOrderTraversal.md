title: '[每日LeetCode] 102. Binary Tree Level Order Traversal'
date: '2019-05-28 10:39:55'
updated: '2019-05-28 10:59:46'
tags: [LeetCode, Tree, Easy]
permalink: /articles/2019/05/28/1559011195220.html
---
原文链接 [[每日LeetCode] 102. Binary Tree Level Order Traversal](https://www.tuhaoxin.cn/articles/2019/05/28/1559011195220.html)

**Description:**

Given a binary tree, return the_level order_traversal of its nodes' values. (ie, from left to right, level by level).

For example:  
Given binary tree `[3,9,20,null,null,15,7]` ,  

```
    3
   / \
  9  20
    /  \
   15   7
```

return its level order traversal as:  

```
[
  [3],
  [9,20],
  [15,7]
]
```

---
思路：本题要求树的层序遍历，并返回二维数组。采用非递归写法，使用队列，每次对某结点进行访问并把其子结点入队，知道最后一个元素出队。


---
C++代码

```
/**
 * Definition for a binary tree node.
 * struct TreeNode {
 *     int val;
 *     TreeNode *left;
 *     TreeNode *right;
 *     TreeNode(int x) : val(x), left(NULL), right(NULL) {}
 * };
 */
class Solution {
public:
    vector<vector<int>> levelOrder(TreeNode* root) {
        if (!root)
            return {};
        vector<vector<int>> res;
        queue<TreeNode*> q{{root}};
        while(!q.empty()){
             vector<int> oneLevel;
            for (int i=q.size(); i > 0; i--){
                TreeNode* t = q.front();
                q.pop();
                oneLevel.push_back(t->val);
                if (t->left)
                    q.push(t->left);
                if (t->right)
                    q.push(t->right);
            }
            res.push_back(oneLevel);
        }
        return res;
    }
};
```

---
运行时间：8ms

运行内存：13.9M