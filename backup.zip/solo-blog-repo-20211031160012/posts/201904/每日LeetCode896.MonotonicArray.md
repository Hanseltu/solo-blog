title: '[每日LeetCode] 896. Monotonic Array'
date: '2019-04-04 22:27:05'
updated: '2019-04-04 22:34:50'
tags: [LeetCode, Array, Easy]
permalink: /articles/2019/04/04/1554388025650.html
---
Description:

An array is _monotonic_ if it is either monotone increasing or monotone decreasing.

An array `A` is monotone increasing if for all `i <= j` , `A[i] <= A[j]` .  An array `A` is monotone decreasing if for all `i <= j` , `A[i] >= A[j]` .

Return `true` if and only if the given array `A` is monotonic.

**Example 1:**

```
Input: [1,2,2,3]
Output: true
```

**Example 2:**
```
Input: [6,5,4,4]
Output: true
```
**Example 3:**

```
Input: [1,3,2]
Output: false
```

**Example 4:**

```
Input: [1,2,4,5]
Output: true
```

**Example 5:**

```
Input: [1,1,1]
Output: true
```

**Note:**

1.  `1 <= A.length <= 50000`
2.  `-100000 <= A[i] <= 100000`

---
思路：本题要求判断数组是否是单调数组，即数组要么递增要么递减。想到一种方法，遍历数组，判断相邻两个差值的乘积是否小于0，若小于0则返回false，否则返回true。

----
C++代码
```
class Solution {
public:
    bool isMonotonic(vector<int>& A) {
        if(A.size()<=1)
            return true;
        int last=0;
        for(int i=1;i<A.size();i++)
        {
            int diff=A[i]-A[i-1];
            if (last*diff<0)
                return false;
            if(diff!=0)
                last=diff;
        }
        return true;   
    }
};
```

---
运行时间：92ms

运行内存：13.9M