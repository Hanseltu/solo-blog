title: '[每日LeetCode] 674. Longest Continuous Increasing Subsequence'
date: '2019-04-14 22:52:08'
updated: '2019-04-14 22:56:51'
tags: [LeetCode, Array, Easy]
permalink: /articles/2019/04/14/1555253528142.html
---
Description:

Given an unsorted array of integers, find the length of longest `continuous` increasing subsequence (subarray).

**Example 1:**  

```
Input: [1,3,5,4,7]
Output: 3
Explanation: The longest continuous increasing subsequence is [1,3,5], its length is 3. 
Even though [1,3,5,7] is also an increasing subsequence, it's not a continuous one where 5 and 7 are separated by 4. 
```

**Example 2:**  

```
Input: [2,2,2,2,2]
Output: 1
Explanation: The longest continuous increasing subsequence is [2], its length is 1. 
```

**Note:**
Length of the array will not exceed 10,000.

---
思路：本题要求数组中连续最大的递增子序列个数。直接遍历数组，若递增，计数器加1，并及时更新最大长度。

---
C++代码
```
class Solution {
public:
    int findLengthOfLCIS(vector<int>& nums) {
        int size = nums.size();
        if (size == 0)
            return 0;
        int m = 1, count = 1;
        for (int i=0; i<size-1; i++){
            if (nums[i+1] > nums[i]){
                m = max(m,++count);
            }
            else
                cur = 1;
        }
        return m;
    }
};
```

---
运行时间：24ms

运行内存：9.3M