title: '[每日LeetCode] 141. Linked List Cycle'
date: '2019-04-26 21:49:17'
updated: '2019-04-26 21:54:21'
tags: [LeetCode, LinkList, Easy]
permalink: /articles/2019/04/26/1556286557683.html
---
Description:

Given a linked list, determine if it has a cycle in it.

To represent a cycle in the given linked list, we use an integer `pos` which represents the position (0-indexed) in the linked list where tail connects to. If `pos` is `-1`, then there is no cycle in the linked list.

**Example 1:**

```
Input: head = [3,2,0,-4], pos = 1
Output: true
Explanation: There is a cycle in the linked list, where tail connects to the second node.
```

![](https://assets.leetcode.com/uploads/2018/12/07/circularlinkedlist.png)

**Example 2:**

```
Input: head = [1,2], pos = 0
Output: true
Explanation: There is a cycle in the linked list, where tail connects to the first node.
```

![](https://assets.leetcode.com/uploads/2018/12/07/circularlinkedlist_test2.png)

**Example 3:**

```
Input: head = [1], pos = -1
Output: false
Explanation: There is no cycle in the linked list.
```

![](https://assets.leetcode.com/uploads/2018/12/07/circularlinkedlist_test3.png)

**Follow up:**

Can you solve it using _O(1)_ (i.e. constant) memory?

---
思路：本题要求判断链表中是否存在环。考虑使用两个指针，一个走的快，一个走的慢，如果存在环，则两者必然相遇，返回true。

---
C++代码

```
/**
 * Definition for singly-linked list.
 * struct ListNode {
 *     int val;
 *     ListNode *next;
 *     ListNode(int x) : val(x), next(NULL) {}
 * };
 */
class Solution {
public:
    bool hasCycle(ListNode *head) {
        if(head == NULL)
    		return false;
    	ListNode *fast = head;
    	ListNode *slow = head;
    	while(fast->next && fast->next->next)
    	{
    		fast = fast->next->next;
    		slow = slow->next;
    		if(fast == slow)
    			return true;
    	}
    	return false;
    }
};
```

---
运行时间：12ms

运行内存：9.7M