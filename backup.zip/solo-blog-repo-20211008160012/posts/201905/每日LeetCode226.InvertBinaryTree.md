title: '[每日LeetCode] 226. Invert Binary Tree'
date: '2019-05-23 23:49:13'
updated: '2021-03-27 16:28:12'
tags: [LeetCode, Tree, Easy]
permalink: /articles/2019/05/23/1558626553202.html
---
原文链接 [[每日LeetCode] 226. Invert Binary Tree](http://www.tuhaoxin.cn/articles/2019/05/23/1558626553202.html)

**Description:**

Invert a binary tree.

**Example:**

Input:

```
     4
   /   \
  2     7
 / \   / \
1   3 6   9
```

Output:

```
     4
   /   \
  7     2
 / \   / \
9   6 3   1
```

**Trivia:**This problem was inspired by [this original tweet](https://twitter.com/mxcl/status/608682016205344768) by [Max Howell](https://twitter.com/mxcl):

> Google: 90% of our engineers use the software you wrote (Homebrew), but you can’t invert a binary tree on a whiteboard so f*** off.

---

思路：本题要求反转一颗二叉树。比较简单，直接只用递归即可。题目下面有个小槽点，Homebrew的发明者写不出反转二叉树的代码，可以说是调侃，同时也告诫我们不能只刷题不思考其用处，学以致用最重要啦。

---

C++代码

```
/**
 * Definition for a binary tree node.
 * struct TreeNode {
 *     int val;
 *     TreeNode *left;
 *     TreeNode *right;
 *     TreeNode(int x) : val(x), left(NULL), right(NULL) {}
 * };
 */
class Solution {
public:
    TreeNode* invertTree(TreeNode* root) {
        if (!root)
            return NULL;
        TreeNode* head = root;
        TreeNode* temp = root->left;
        root->left = root->right;
        root->right = temp;
        invertTree(root->left);
        invertTree(root->right);
        return head; 
    }
};
```

---

运行时间：4ms

运行内存：9.2M
