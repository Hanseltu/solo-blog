title: '[每日LeetCode] 709. To Lower Case'
date: '2019-07-04 23:48:46'
updated: '2019-07-04 23:49:17'
tags: [LeetCode, String, Easy]
permalink: /articles/2019/07/04/1562255326023.html
---
原文链接 [[每日LeetCode] 709. To Lower Case](https://www.tuhaoxin.cn/articles/2019/07/04/1562255326023.html)


**Description:**

Implement function ToLowerCase( ) that has a string parameter str, and returns the same string in lowercase.

**Example 1:**

```
Input: "Hello"
Output: "hello"
```

**Example 2:**

```
Input: "here"
Output: "here"
```

**Example 3:**

```
Input: "LOVELY"
Output: "lovely"
```

----
思路：本题的题意是将字符串中的大写字母转化为小写字母。比较简单，提供两种方法。一种常规遍历，若遇到大写字母则加上32，否则不处理；另外一种调用STL tolower( ) 直接处理。


----
C++代码（常规方法）


class Solution {
public:
    string toLowerCase(string str) {
        for(int i=0;i<str.length();i++){
            if(str[i]>='A'&&str[i]<='Z')
                str[i]+=32;
        }
        return str;
    }
};

运行时间：0ms

运行内存：8.4M

----
C++代码（STL方法）

```
class Solution {
public:
    string toLowerCase(string str) {
        for(auto& c : str)
            c = std::tolower(c);
        return str;
    }
};
```

运行时间：0ms

运行内存：8.1M

