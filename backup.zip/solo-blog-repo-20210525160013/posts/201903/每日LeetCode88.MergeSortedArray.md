title: '[每日LeetCode] 88. Merge Sorted Array'
date: '2019-03-19 22:36:40'
updated: '2019-03-19 22:41:16'
tags: [LeetCode, Array, Easy]
permalink: /articles/2019/03/19/1553006200606.html
---
Description:

Given two sorted integer arrays _nums1_ and _nums2_ , merge _nums2_ into _nums1_ as one sorted array.

**Note:**

*   The number of elements initialized in _nums1_ and _nums2_ are _m_ and _n_ respectively.
*   You may assume that _nums1_ has enough space (size that is greater or equal to _m_ + _n_ ) to hold additional elements from _nums2_ .

**Example:**

```
Input:
nums1 = [1,2,3,0,0,0], m = 3
nums2 = [2,5,6],       n = 3
Output: [1,2,2,3,5,6]
```
---
思路：本题要求合并有序数组。考虑简单粗暴的方法，三行代码搞定，把第二个数组插入到第一个数组后面，然后对第一个数组进行排序。

----
C++代码
```
class Solution {
public:
    void merge(vector<int>& nums1, int m, vector<int>& nums2, int n) {
        for(int i=0; i<n; i++){
          nums1[m+i] = nums2[i];
        }
        sort(nums1.begin(),nums1.end());
    }
};
```

---
运行时间：12ms

运行内存：8.9M