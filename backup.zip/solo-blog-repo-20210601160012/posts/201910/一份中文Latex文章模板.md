title: 一份中文Latex文章模板
date: '2019-10-04 18:02:22'
updated: '2020-03-01 18:17:32'
tags: [工具]
permalink: /articles/2019/10/04/1570183342838.html
---
原文链接： [一份中文 Latex 文章模板]()

今天用 LaTeX 写课程作业，想找一个可以成功编译的 Latex 中文文章模板，未果。

在此记录下一份 Mac 下中文文章模板，下次直接拿来用就好了。

> 环境：Mac 下 TeXstudio 2.12.14
> 编译器选择：xelatex

正文如下：

```
\documentclass[9pt, a4paper]{extarticle}
\usepackage{fontspec, xunicode, xltxtra, graphicx, subfig}  
\usepackage{xeCJK}
\setmainfont{Times New Roman}  
\setCJKmainfont{Songti SC}

\title{\Huge{\textbf{这是一份中文LaTeX文章模板}}}
\author{姓名：\textbf{xxx} }

\begin{document}

\maketitle

\tableofcontents
%\newpage

\section{概述}

\section{第一章}

\subsection{研究背景意义}

\subsection{主要研究现状}

\begin{enumerate}

	\item 第一点

	\item 第二点

\end{enumerate}

\subsection{小结}

%\newpage
\renewcommand \refname{参考文献}
\bibliographystyle{plain}
\bibliography{ref}
\end{document}

```

效果如下：

![latexinchinese.png](https://img.hacpai.com/file/2019/10/latexinchinese-de44e043.png)
