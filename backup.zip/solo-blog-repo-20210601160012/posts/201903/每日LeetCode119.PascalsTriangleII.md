title: '[每日LeetCode] 119. Pascal''s Triangle II'
date: '2019-03-22 21:43:56'
updated: '2019-03-22 21:49:42'
tags: [LeetCode, Array, Easy]
permalink: /articles/2019/03/22/1553262235975.html
---
Description:

Given a non-negative index _k_ where _k_ ≤ 33, return the _k_ th index row of the Pascal's triangle.

Note that the row index starts from 0.

![](https://upload.wikimedia.org/wikipedia/commons/0/0d/PascalTriangleAnimated2.gif)  

In Pascal's triangle, each number is the sum of the two numbers directly above it.

**Example:**

```
Input: 3
Output: [1,3,3,1]
```
---
思路：本题是118.Pascal's Triangle的变形，似乎在118题的基础上更简单了，本题只要求输出特定的行，因此只需在118题的基础上输出rowIndex行。注意数组下标是从0开始的。

-----
C++代码

```
class Solution {
public:
    vector<int> getRow(int rowIndex) {
        vector<vector<int>> ret;
        for (int i=0; i<rowIndex + 1; i++){
            vector<int> temp(i+1);
            temp[0] = temp[i] = 1;
            for (int j=1; j<i;j++){
                temp[j] = ret[i-1][j] + ret[i-1][j-1];
            }
             ret.push_back(temp);
        }
        return ret[rowIndex];
    }
};
```

----
运行时间：4ms

运行内存：8.4M
