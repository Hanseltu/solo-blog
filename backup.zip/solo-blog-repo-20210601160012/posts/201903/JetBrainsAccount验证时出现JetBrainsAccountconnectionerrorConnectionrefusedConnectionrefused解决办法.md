title: 'JetBrains Account验证时出现JetBrains Account connection error: Connection refused
  (Connection refused)解决办法'
date: '2019-03-25 08:53:51'
updated: '2019-03-25 23:50:40'
tags: [问题解决]
permalink: /articles/2019/03/25/1553475230919.html
---
刚在JetBrain Account上申请了学生账户，学生账户长下面这个样子，有一年的免费期，到期再续。JetBrain家族的软件太多了用起来也很方便，暂时用了CLion和Pycharm。

![account.png](https://img.hacpai.com/file/2019/03/account-0287553b.png)


可是使用账户登录的时候会出现JetBrains Account connection error: Connection refused (Connection refused)错误，报错如下：

![errors.png](https://img.hacpai.com/file/2019/03/errors-368325b7.png)

**解决方案**：在任何操作系统下的原理应该是一样的，需要在hosts文件中把和account JetBrain有关的host注释掉，Mac的hosts位于/private/etc/hosts，改完后的hosts如下：

![hosts.png](https://img.hacpai.com/file/2019/03/hosts-3361bece.png)


重新激活账户即可。

参考：[解决IDEA授权报错]([https://www.cnblogs.com/ae6623/p/8874315.html](https://www.cnblogs.com/ae6623/p/8874315.html))




