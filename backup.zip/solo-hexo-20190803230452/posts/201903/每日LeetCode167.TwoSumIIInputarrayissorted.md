title: '[每日LeetCode] 167. Two Sum II - Input array is sorted'
date: '2019-03-27 21:56:03'
updated: '2019-03-27 22:11:14'
tags: [LeetCode, Array, Easy]
permalink: /articles/2019/03/27/1553694963651.html
---
Description:

Given an array of integers that is already **_sorted in ascending order_** , find two numbers such that they add up to a specific target number.

The function twoSum should return indices of the two numbers such that they add up to the target, where index1 must be less than index2.

**Note:**

*   Your returned answers (both index1 and index2) are not zero-based.
*   You may assume that each input would have_exactly_one solution and you may not use the_same_element twice.

**Example:**

```
Input: numbers = [2,7,11,15], target = 9
Output: [1,2]
Explanation: The sum of 2 and 7 is 9. Therefore index1 = 1, index2 = 2.
```

---
思路：本题是Two Sum基础版的升级，考虑使用从两边同时扫描的办法，如果两个数的和小于target，左边右移一位，如果两个数的和大于target，右边左移一位，直到左右两边相遇。

----
C++代码
```
class Solution {
public:
    vector<int> twoSum(vector<int>& numbers, int target) {
        int l = 0, r = numbers.size() - 1;
        while (l < r) {
            int sum = numbers[l] + numbers[r];
            if (sum == target) 
                return {l + 1, r + 1};
            else if (sum < target) 
                ++l;
            else 
                --r;
        }
        return {};
    }
};
```
----
运行时间：8ms

运行内存：9.6M