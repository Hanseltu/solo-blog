title: '[每日LeetCode] 203. Remove Linked List Elements'
date: '2019-04-27 21:44:01'
updated: '2019-04-27 21:47:11'
tags: [LeetCode, LinkList, Easy]
permalink: /articles/2019/04/27/1556372641577.html
---
Description:

Remove all elements from a linked list of integers that have value **_val_**.

**Example:**

```
Input:  1->2->6->3->4->5->6, _**val**_ = 6
Output: 1->2->3->4->5
```

---
思路：本题删除链表中的指定节点。比较简单，首先考虑头结点是否是指定节点，若不是则向后遍历，遇到指定节点直接跳过即可。

---
C++代码
```
/**
 * Definition for singly-linked list.
 * struct ListNode {
 *     int val;
 *     ListNode *next;
 *     ListNode(int x) : val(x), next(NULL) {}
 * };
 */
class Solution {
public:
    ListNode* removeElements(ListNode* head, int val) {
        if (!head) return NULL;
        while(head->val == val) 
        {
            head = head->next; 
            if (!head) 
                return NULL;
        }
        ListNode* res = head;
        while(head->next)
        {
            if(head->next->val == val) 
                head->next = head->next->next;
            else 
                head = head->next;
        }
        return res;
    }
};
```

----
运行时间：28ms

运行内存：11M