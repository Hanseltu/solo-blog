title: '[每日LeetCode] 965. Univalued Binary Tree'
date: '2019-05-11 20:07:59'
updated: '2021-03-27 16:28:43'
tags: [LeetCode, Tree, Easy]
permalink: /articles/2019/05/11/1557576479663.html
---
原文链接 [[每日LeetCode] 965. Univalued Binary Tree](http://www.tuhaoxin.cn/articles/2019/05/11/1557576479663.html)

**Description:**

A binary tree is _univalued_ if every node in the tree has the same value.

Return `true` if and only if the given tree is univalued.

**Example 1:**

![](https://assets.leetcode.com/uploads/2018/12/28/unival_bst_1.png)```
**Input:** [1,1,1,1,1,null,1]
**Output:** true

**Example 2:**

![](https://assets.leetcode.com/uploads/2018/12/28/unival_bst_2.png)```
**Input:** [2,2,2,5,2]
**Output:** false

---

思路：本题要求判断二叉树中每个结点的值是否相同，直接遍历即可，这里使用DFS。

---

C++代码

```
/**
 * Definition for a binary tree node.
 * struct TreeNode {
 *     int val;
 *     TreeNode *left;
 *     TreeNode *right;
 *     TreeNode(int x) : val(x), left(NULL), right(NULL) {}
 * };
 */
class Solution {
public:
    bool isUnivalTree(TreeNode* root) {
        return dfs(root->left, root->val) && dfs(root->right, root->val);
    }
    bool dfs(TreeNode* root, int value){
        if (!root)
            return true;
        if (root->val != value)
            return false;
        return dfs(root->left, value) && dfs(root->right, value);
    }
};
```

---

运行时间：4ms

运行内存：10.8M
